# TaskFlow — Python Mini Project Website

A responsive multi-page To-Do List website UI suitable as the frontend for a Python mini project.

## Pages
- `index.html` — Login
- `dashboard.html` — Dashboard and statistics
- `tasks.html` — Add, edit, complete, delete, search, filter and sort tasks
- `settings.html` — Export CSV and clear data

## Features
- Login UI
- Add/Edit/Delete tasks
- Mark tasks complete
- Priority: High / Medium / Low
- Due dates
- Categories
- Search, filter and sort
- Dashboard statistics
- CSV export
- LocalStorage persistence
- Responsive design

## Run
Open `index.html` in a browser. For VS Code, you can use the Live Server extension.

## Python integration
For a Python mini project, this frontend can later be connected to Flask or Django, with SQLite used as the database and Python handling login, CRUD operations and APIs.
