function getTasks(){return JSON.parse(localStorage.getItem("taskflowTasks")||"[]")}
function saveTasks(t){localStorage.setItem("taskflowTasks",JSON.stringify(t))}
function requireLogin(){if(!localStorage.getItem("taskflowUser"))location.href="index.html"}
function logout(){localStorage.removeItem("taskflowUser");location.href="index.html"}
function esc(s){return String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function renderDashboard(){
 const t=getTasks(), done=t.filter(x=>x.completed), pending=t.filter(x=>!x.completed), high=t.filter(x=>x.priority==="High");
 document.getElementById("total").textContent=t.length;document.getElementById("done").textContent=done.length;document.getElementById("pending").textContent=pending.length;document.getElementById("high").textContent=high.length;
 const u=localStorage.getItem("taskflowUser")||"User";document.getElementById("hello").textContent="Welcome, "+u.split("@")[0];
 const r=document.getElementById("recent");let recent=[...t].reverse().slice(0,5);r.innerHTML=recent.length?recent.map(taskHTML).join(""):'<div class="empty">No tasks yet. Click “Add Task” to get started.</div>';
}
function taskHTML(x){
 return `<div class="task ${x.completed?"completed":""}"><input class="task-check" type="checkbox" ${x.completed?"checked":""} onchange="toggleTask('${x.id}')"><div class="task-main"><div class="task-title">${esc(x.title)}</div><div class="task-desc">${esc(x.desc)}</div><div class="badges"><span class="badge">${esc(x.category)}</span><span class="badge ${x.priority.toLowerCase()}">${x.priority} Priority</span>${x.due?`<span class="badge">📅 ${x.due}</span>`:""}</div></div><div class="actions"><button class="icon-btn" onclick="editTask('${x.id}')">✎</button><button class="icon-btn" onclick="deleteTask('${x.id}')">🗑</button></div></div>`
}
function renderTasks(){
 const list=document.getElementById("taskList");if(!list)return;let t=getTasks(),q=(document.getElementById("search")?.value||"").toLowerCase(),f=document.getElementById("filter")?.value||"all",s=document.getElementById("sort")?.value||"new";
 t=t.filter(x=>x.title.toLowerCase().includes(q)||x.desc.toLowerCase().includes(q)||x.category.toLowerCase().includes(q));
 if(f==="pending")t=t.filter(x=>!x.completed);if(f==="completed")t=t.filter(x=>x.completed);if(f==="high")t=t.filter(x=>x.priority==="High");
 if(s==="priority"){let p={High:0,Medium:1,Low:2};t.sort((a,b)=>p[a.priority]-p[b.priority])}
 if(s==="date")t.sort((a,b)=>(a.due||"9999").localeCompare(b.due||"9999"));if(s==="new")t.reverse();
 list.innerHTML=t.length?t.map(taskHTML).join(""):'<div class="empty">No matching tasks found.</div>';
}
function openModal(id){document.getElementById("modal").classList.remove("hidden");document.getElementById("taskForm").reset();document.getElementById("taskId").value="";
 document.getElementById("modalTitle").textContent="Add New Task";
 if(id){let x=getTasks().find(t=>t.id===id);if(!x)return;document.getElementById("modalTitle").textContent="Edit Task";["title","desc","category","priority","due"].forEach(k=>document.getElementById(k).value=x[k]||"");document.getElementById("taskId").value=id}
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.addEventListener("submit",e=>{if(e.target.id!=="taskForm")return;e.preventDefault();let t=getTasks(),id=document.getElementById("taskId").value,x={id:id||Date.now().toString(),title:document.getElementById("title").value.trim(),desc:document.getElementById("desc").value.trim(),category:document.getElementById("category").value,priority:document.getElementById("priority").value,due:document.getElementById("due").value,completed:false};
 if(id){let old=t.find(a=>a.id===id);x.completed=old.completed;t=t.map(a=>a.id===id?x:a)}else t.push(x);saveTasks(t);closeModal();renderTasks();if(typeof renderDashboard==="function")renderDashboard()});
function toggleTask(id){let t=getTasks().map(x=>x.id===id?{...x,completed:!x.completed}:x);saveTasks(t);renderTasks();if(typeof renderDashboard==="function")renderDashboard()}
function deleteTask(id){if(confirm("Delete this task?")){saveTasks(getTasks().filter(x=>x.id!==id));renderTasks();if(typeof renderDashboard==="function")renderDashboard()}}
function editTask(id){openModal(id)}
function clearTasks(){if(confirm("Delete all tasks?")){saveTasks([]);alert("All tasks cleared.");location.reload()}}
function exportCSV(){let t=getTasks();let csv="Title,Description,Category,Priority,Due Date,Status\n"+t.map(x=>[x.title,x.desc,x.category,x.priority,x.due,x.completed?"Completed":"Pending"].map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="taskflow-tasks.csv";a.click()}
